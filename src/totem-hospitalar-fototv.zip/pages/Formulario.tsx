import { useState, useRef } from "react";
import { useNavigate, NavLink } from 'react-router-dom';
import LogoHospitalar from '../assets/logo-hospitalar.png';
import { ArrowLeft } from 'lucide-react';
import { PatternFormat } from 'react-number-format';
import KeyboardReact from 'react-simple-keyboard';
import "react-simple-keyboard/build/css/index.css";
import { apiUrl } from '../api';

const Keyboard = (KeyboardReact as any).default || KeyboardReact;

export default function Formulario() {
    const navigate = useNavigate();
    const [phone, setPhone] = useState("");
    const [name, setName] = useState("");
    const [email, setEmail] = useState("");
    const [isClient, setIsClient] = useState<boolean | null>(null);
    const [emailOptions, setEmailOptions] = useState(false);
    const [inputName, setInputName] = useState<string>("name");
    const [layoutName, setLayoutName] = useState('default');
    const [emailError, setEmailError] = useState("");
    const keyboardRef = useRef<any>(null);

    const emailsType = [
        { "id": 1, "value": "gmail.com" },
        { "id": 2, "value": "hotmail.com" },
        { "id": 3, "value": "outlook.com" },
        { "id": 4, "value": "yahoo.com" },
        { "id": 5, "value": "icloud.com" },
        { "id": 6, "value": "uol.com.br" }
    ];

    const validateEmail = (email: string) => {
        const re = /^(?!\.)(?!.*?\.\.)[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
        return re.test(email);
    };

    const isFormValid = (phone !== '' && name !== '' && email !== '' && isClient !== null && validateEmail(email));

    const handleFocus = (name: string, value: string) => {
        setInputName(name);
        if (keyboardRef.current) {
            keyboardRef.current.setInput(value);
        }
    };

    const onKeyboardChange = (inputVal: string) => {
        if (inputName === "name") setName(inputVal);

        if (inputName === "email") {
            const sanitized = inputVal
                .toLowerCase()
                .replace(/\s/g, '')
                .replace(/\.{2,}/g, '.')
                .replace(/\._/g, '.')
                .replace(/_\./g, '_');

            setEmail(sanitized);

            const hasAt = sanitized.includes('@');
            const afterAt = hasAt ? sanitized.split('@')[1] : "";
            setEmailOptions(hasAt && afterAt.length === 0);

            if (sanitized === "" || validateEmail(sanitized)) {
                setEmailError("");
            } else {
                setEmailError("E-mail com formato inválido");
            }
        }

        if (inputName === "phone") setPhone(inputVal);
    };

    const handleShift = () => {
        setLayoutName(layoutName === "default" ? "shift" : "default");
    };

    const onKeyPress = (button: string) => {
        if (button === "{shift}" || button === "{lock}") {
            handleShift();
        }
    };

    function formatPhone(phone: string) {
    
        const numbers = phone.replace(/\D/g, "").slice(0, 11);

        if (numbers.length <= 10) {
            return numbers.replace(/^(\d{2})(\d{4})(\d{0,4})$/, "($1) $2-$3").replace(/-$/, "");
        } else {
            return numbers.replace(/^(\d{2})(\d{5})(\d{4})$/, "($1) $2-$3");
        }
    }

    async function createLead() {
        if (!validateEmail(email)) {
            setEmailError("Verifique o formato do e-mail (ex: nome@dominio.com)");
            return;
        }

        if (!isFormValid) return;

        try {
            const response = await fetch(apiUrl('/leads'), {
                method: "POST",
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    name: name,
                    email: email,
                    phone: formatPhone(phone),
                    is_client: isClient ? 'Sim' : 'Não'
                })
            });
            if (response.ok) navigate('/roleta');
        } catch (error) {
            console.error(error);
        }
    }

    return (
        <div className="flex flex-col items-center justify-start min-h-screen gap-10 pb-32 pt-10 w-full bg-white p-6">
            <div className='flex justify-between items-center w-full max-w-6xl z-20'>
                <img src={LogoHospitalar} className="h-32 w-auto object-contain" alt="Logo" />
                <NavLink to={'/'} className="p-4 bg-white rounded-full shadow-md">
                    <ArrowLeft size={60} color='#0262b0' />
                </NavLink>
            </div>

            <div className="bg-[#003e82]/20 p-8 rounded-[40px] shadow-2xl w-full max-w-2xl flex flex-col h-auto py-20 gap-5">
                <h2 className="text-3xl font-extrabold text-gray-800 text-center mb-2">Preencha o formulário</h2>

                <div className="grid grid-cols-2 gap-4">
                    <div className="flex flex-col gap-3">
                        <label className="text-xl font-bold text-gray-600 ml-2">Nome Completo</label>
                        <input
                            id="name"
                            type="text"
                            readOnly
                            value={name}
                            onFocus={() => handleFocus("name", name)}
                            placeholder="Digite seu nome"
                            className={`w-full h-14 px-6 text-2xl rounded-2xl bg-gray-50 border-2 transition-all outline-none ${inputName === 'name' ? 'border-black' : 'border-white'}`}
                        />
                    </div>
                    <div className="flex flex-col gap-3">
                        <label className="text-xl font-bold text-gray-600 ml-2">Telefone</label>
                        <PatternFormat
                            id="phone"
                            format="(##) #####-####"
                            mask="_"
                            value={phone}
                            readOnly
                            onFocus={() => handleFocus("phone", phone)}
                            placeholder="(99) 99999-9999"
                            className={`w-full h-14 px-6 text-2xl rounded-2xl bg-gray-50 border-2 transition-all outline-none ${inputName === 'phone' ? 'border-black' : 'border-white'}`}
                        />
                    </div>
                </div>

                <div className="flex flex-col gap-3">
                    <label className="text-xl font-bold text-gray-600 ml-2">E-mail</label>
                    <input
                        id="email"
                        type="email"
                        value={email}
                        readOnly
                        onFocus={() => handleFocus("email", email)}
                        placeholder="email@exemplo.com"
                        className={`w-full h-14 px-6 text-2xl rounded-2xl bg-gray-50 border-2 transition-all outline-none ${inputName === 'email' ? ' border-black' : (emailError ? 'border-red-500' : 'border-white')}`}
                    />
                    {emailOptions && (
                        <div className="grid grid-cols-3 gap-2 mt-2">
                            {emailsType.map((item) => (
                                <button
                                    key={item.id}
                                    type="button"
                                    className="p-3 rounded-xl border bg-white hover:bg-blue-50 text-[#003e82] font-bold shadow-sm transition-colors"
                                    onClick={() => {
                                        const prefix = email.split('@')[0];
                                        const newEmail = prefix + '@' + item.value;
                                        setEmail(newEmail);
                                        setEmailOptions(false);
                                        setEmailError("");
                                        if (keyboardRef.current) keyboardRef.current.setInput(newEmail);
                                    }}
                                >
                                    @{item.value}
                                </button>
                            ))}
                        </div>
                    )}
                </div>

                <div className="mt-4 p-4 bg-white/50 rounded-3xl shadow-inner text-black relative z-50">
                    <Keyboard
                        keyboardRef={(r: any) => (keyboardRef.current = r)}
                        layoutName={layoutName}
                        onChange={onKeyboardChange}
                        onKeyPress={onKeyPress}
                        layout={{
                            default: [
                                "1 2 3 4 5 6 7 8 9 0",
                                "q w e r t y u i o p á é í",
                                "a s d f g h j k l ó ú ç",
                                "{shift} z x c v b n m ã {backspace}",
                                "@ . _ - + * .com .br {space}"
                            ],
                            shift: [
                                "! @ # $ % ¨ & * ( )",
                                "Q W E R T Y U I O P Á É Í",
                                "A S D F G H J K L Ó Ú Ç",
                                "{shift} Z X C V B N M Ã {backspace}",
                                "@ . _ - + ? ^ ~ .com .br {space}"
                            ]
                        }}
                        display={{
                            "{backspace}": "⌫ Apagar",
                            "{shift}": "⇧",
                            "{space}": "Espaço",
                            ".com": ".com",
                            ".br": ".br",
                            "@": "@",
                        }}
                    />
                </div>

                <div className="flex items-center gap-6 p-4 rounded-2xl bg-gray-50 border border-gray-200 w-full my-2">
                    <span className="text-xl font-bold text-gray-700 whitespace-nowrap">É cliente Hospitalar?</span>
                    <div className="flex gap-4">
                        <button type="button" onClick={() => setIsClient(true)} className="flex items-center gap-3">
                            <div className={`w-8 h-8 rounded-lg border-2 flex items-center justify-center ${isClient === true ? 'bg-black' : 'bg-white border-gray-300'}`}>
                                {isClient === true && <svg className="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={4}><path d="M5 13l4 4L19 7" /></svg>}
                            </div>
                            <span className={`text-xl font-semibold ${isClient === true ? 'text-black' : 'text-gray-500'}`}>Sim</span>
                        </button>
                        <button type="button" onClick={() => setIsClient(false)} className="flex items-center gap-3">
                            <div className={`w-8 h-8 rounded-lg border-2 flex items-center justify-center ${isClient === false ? 'bg-black ' : 'bg-white border-gray-300'}`}>
                                {isClient === false && <svg className="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={4}><path d="M5 13l4 4L19 7" /></svg>}
                            </div>
                            <span className={`text-xl font-semibold ${isClient === false ? 'text-black' : 'text-gray-500'}`}>Não</span>
                        </button>
                    </div>
                </div>

                <NavLink
                    type="button"
                    onClick={isFormValid ? createLead : () => {}}
                    to={isFormValid ? "/roleta" : ""}
                    className={`w-full text-center ${isFormValid ? 'bg-black' : 'bg-black'} text-white font-bold text-xl py-6 rounded-2xl shadow-lg mt-20 uppercase transition-all`}
                >
                    {(!validateEmail(email) && email !== "") ? 'E-mail Inválido' : (isFormValid ? 'Confirmar Cadastro' : 'Preencha os dados')}
                </NavLink>
            </div>
        </div>
    );
}