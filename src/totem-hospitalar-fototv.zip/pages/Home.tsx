import { NavLink } from 'react-router-dom'
import FotoTV from '../assets/foto-campanha-tv.jpg'

export default function Home() {
  return (
    <div className='w-full h-full overflow-hidden'>
      <NavLink to={'/forms'}>
        <img src={FotoTV} alt="foto-tv" className="w-full h-full object-cover" />
      </NavLink>
    </div>
  )
}
